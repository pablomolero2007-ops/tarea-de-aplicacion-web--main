<?php
/**
 * Configuración de la base de datos
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'alumno4_ejmplo');
define('DB_PASS', 'y4Yg4m(0QG2f#vRJ');
define('DB_NAME', 'alumno4_ejmplo');
